class Product < ApplicationRecord
	has_many :orders
end
