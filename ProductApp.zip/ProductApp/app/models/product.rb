class Product < ApplicationRecord
	has_many :orders
	 validates :product_name,:product_detail,:product_price ,presence: true

end
