class Order < ApplicationRecord
	belongs_to :product
	
	  validates :name,:phone,:address,:delivery,:product_id,:payment,:quantity,:status ,presence: true
end
