class Order < ApplicationRecord
	belongs_to :product
end
